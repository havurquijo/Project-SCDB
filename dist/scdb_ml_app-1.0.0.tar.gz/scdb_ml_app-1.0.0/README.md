# Machine Learning of the Supreme Court Database

## Table of content
[Installation](#installation)
[Usage and requirements](#usage-and-requirements)
[Machine learning models](#machine-learning-models)
[Interpretation](#interpretation)

# Installation

# Usage and Requirements

# Machine learning models

# Interpretation
